# Afnan Barind Agricultural Technology & Resilience Dashboard

A deployable Streamlit dashboard for the Mahadebpur–Sapahar Barind pilot.

## What is included

- V0.1 BMDA technology/irrigation diagnostics (T)
- V0.1 WARPO/IWM water, groundwater and stress diagnostics (R/E)
- V0.1 BBS Naogaon district productivity context (context only)
- V0.2 CHIRPS monthly rainfall, 2001–2025
- V0.2 finalized monthly MODIS NDVI/EVI, 2001–2025
- Resilience explorer using calendar-month standardized rainfall and vegetation anomalies
- QA/interpolation audit and downloadable clean data

The dashboard intentionally does **not** estimate final welfare U and does **not** claim causal effects from the exploratory shock diagnostics.

## Run locally

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Extract this ZIP.
2. Create a new GitHub repository.
3. Upload the **contents** of this folder to the repository root (`app.py`, `requirements.txt`, `data/`, `.streamlit/`, etc.).
4. Go to Streamlit Community Cloud and choose **Create app**.
5. Select your GitHub repository and branch (`main`).
6. Set the main file path to `app.py`.
7. Click **Deploy**.

No secrets, API keys, Earth Engine account, or external database are required for the deployed dashboard because the finalized data are bundled as CSV files.

## Main model file

`data/v02_monthly_panel.csv` is the primary longitudinal modeling dataset.

## Important caveats

- MODIS NDVI/EVI are vegetation-greenness proxies, not direct crop yield.
- Seven completely missing MODIS upazila-months were transparently interpolated and flagged.
- The V0.1 groundwater stress score is a derived ordinal score using official category counts; it is not official IWM WSI.
- BMDA reported equipment service areas may overlap and should not automatically be interpreted as unique irrigated land.
- BBS crop productivity in this package is Naogaon district context, not focal-upazila P.
